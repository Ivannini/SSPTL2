export class Arbol {
    constructor() {
        this.raiz = [];
    }
}

export class Nodo {
    constructor() {
        this.ramas = [];
        this.simbolo = "";
    }

    toArray() {
        return []; 
    }

}